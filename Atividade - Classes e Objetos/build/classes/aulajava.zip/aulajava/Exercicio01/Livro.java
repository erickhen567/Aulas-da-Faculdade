package aulajava.Exercicio01;

public class Livro {
    private String titulo;
    private String autor;
    private int numPag;
    
    
}
