const express = require('express'); //Chamar o módulo Express (Framework)

const app = express(); //Inicializar a aplicação do Express

const port = 2003; //Estabelecer a porta do servidor

//Trabalhar com requisições (JSON)
app.use(express.urlencoded({extend: true}));

//Arquivo estático (Middleware)
app.use(express.static('public'));

//Rotas (/) -> GET (Caminho raiz '/')
app.get('/', (req, res) =>{
    //res.send('Rota Padrão');
    res.sendFile(__dirname + 'public/index.html');
});

app.get('/me', (req, res) =>{
    res.send('Nome: Erick');
});

app.get('/me', (req, res) =>{
    res.send('Nome: Erick');
});

//Criar a rota do Contato
app.post('/contato', (req, res) =>{
    //res.send("Dados Recebidos!");
    const {nome, email} = req.body; //Acessar o corpo da requisição
    res.send(`Dados Recebidos!: ${nome}, ${email}`);
});

//Inicializar a porta do Servidor
app.listen(port, () =>{
    console.log("Servidor rodando na porta 2003");
});