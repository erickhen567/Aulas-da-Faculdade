CREATE DATABASE userdb_1; -- criar o bando de dados


USE userdb_1; -- criar usuário

-- criar a tabela de usuários,

CREATE TABLE users (
	-- id, nome, email
    id int auto_increment primary key,
    nome varchar(100) not null,
    email varchar(100) not null
    
)

-- executar (consulta)
select * from users;
DROP DATABASE userdb_1;