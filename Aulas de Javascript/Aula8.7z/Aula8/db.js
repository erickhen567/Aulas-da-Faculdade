//Arquivo para gerar a conexão com o Banco de Dados
const mysql = require('mysql2');

//Criar isntância de conexão
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'catolica',
    database: 'userdb_1', 
    port: '3307',
});

//Estabelecer a conexão
db.connect(err =>{
    if (err) throw err;
    console.log('Conectado com sucesso');
});

//Exportar o módulo de conexão do banco

module.exports = db;