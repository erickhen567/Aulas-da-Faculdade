//Arquivo principal (entry point)
const express = require('express');
const app = express();
const port = 3000;
const path = require('path') //Puxar o caminho dos arquivos estáticos

//Informar o lugar dos arquivos estáticos
app.use(express.static('public'));

//Criar a conexão com o Banco de Dados
const db = require('./db');

//Rotas do Sistema
app.get('/', (req, res) =>{
    //res.send('Funcionando');
    res.sendFile(path.join(__dirname, 'public','index.html')); //Disponibilizar a página front-end para o cliente
});

//Vincular o servidor a porta
app.listen(port, () =>{
    console.log("Servidor bombando!!");
});
