package JavaHerancas;

// A classe EmpregadoComissionado representa um empregado que recebe
// uma porcentagem sobre as vendas brutas.
public class EmpregadoComissionado extends Object {
    private final String primeiroNome;
    private final String sobrenome;
    private final String numeroSegurancaSocial;
    private double vendasBrutas; // vendas brutas semanais
    private double taxaComissao; // porcentagem da comissão

    // Construtor com cinco argumentos
    public EmpregadoComissionado(String primeiroNome, String sobrenome,
                                 String numeroSegurancaSocial, double vendasBrutas,
                                 double taxaComissao) {
        // se vendasBrutas for inválido, lança uma exceção
        if (vendasBrutas < 0.0)
            throw new IllegalArgumentException("Vendas brutas devem ser >= 0.0");

        // se taxaComissao for inválida, lança uma exceção
        if (taxaComissao <= 0.0 || taxaComissao >= 1.0)
            throw new IllegalArgumentException("A taxa de comissao deve ser > 0.0 e < 1.0");

        this.primeiroNome = primeiroNome;
        this.sobrenome = sobrenome;
        this.numeroSegurancaSocial = numeroSegurancaSocial;
        this.vendasBrutas = vendasBrutas;
        this.taxaComissao = taxaComissao;
    }

    // Retorna o primeiro nome
    public String getPrimeiroNome() {
        return primeiroNome;
    }

    // Retorna o sobrenome
    public String getSobrenome() {
        return sobrenome;
    }

    // Retorna o número do seguro social
    public String getNumeroSegurancaSocial() {
        return numeroSegurancaSocial;
    }

    // Define o valor das vendas brutas
    public void setVendasBrutas(double vendasBrutas) {
        if (vendasBrutas < 0.0)
            throw new IllegalArgumentException("Vendas brutas devem ser >= 0.0");

        this.vendasBrutas = vendasBrutas;
    }

    // Retorna o valor das vendas brutas
    public double getVendasBrutas() {
        return vendasBrutas;
    }

    // Define a taxa de comissão
    public void setTaxaComissao(double taxaComissao) {
        if (taxaComissao <= 0.0 || taxaComissao >= 1.0)
            throw new IllegalArgumentException("A taxa de comissao deve ser > 0.0 e < 1.0");

        this.taxaComissao = taxaComissao;
    }

    // Retorna a taxa de comissão
    public double getTaxaComissao() {
        return taxaComissao;
    }

    // Calcula os rendimentos
    public double rendimentos() {
        return taxaComissao * vendasBrutas;
    }

    // Retorna a representação em String do objeto EmpregadoComissionado
    @Override
    public String toString() {
        return String.format("%s: %s %s%n%s: %s%n%s: %.2f%n%s: %.2f",
                "Empregado comissionado", primeiroNome, sobrenome,
                "Numero do seguro social", numeroSegurancaSocial,
                "Vendas brutas", vendasBrutas,
                "Taxa de comissao", taxaComissao);
    }
}