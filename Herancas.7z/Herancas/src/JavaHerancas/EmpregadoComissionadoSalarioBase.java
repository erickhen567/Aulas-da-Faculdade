package JavaHerancas;

public class EmpregadoComissionadoSalarioBase extends EmpregadoComissionado {
    public double salarioBase;
    
    public EmpregadoComissionadoSalarioBase(String primeiroNome, String sobrenome,
                                 String numeroSegurancaSocial, double vendasBrutas,
                                 double taxaComissao, double salarioBase){
        super(primeiroNome, sobrenome, numeroSegurancaSocial, vendasBrutas, taxaComissao);
        
        //inserir a restrição de inserção do salário base
        if(salarioBase > 0){
            this.salarioBase = salarioBase;
        }else{
            throw new IllegalArgumentException("Valor Invalido!");
        }
    }
    
    public double getSalarioBase() {
        return salarioBase;
    }
    public void setSalarioBase(double salarioBase) {
        //inserir a restrição de inserção do salário base
        if(salarioBase > 0){
            this.salarioBase = salarioBase;
        }else{
            throw new IllegalArgumentException("Valor Invalido!");
    }
  }
        // Calcula os rendimentos
        @Override
        public double rendimentos() {
            return salarioBase + (getTaxaComissao() * getVendasBrutas());
    }
    
    @Override
    public String toString(){
        return String.format("Informacoes do Objeto: "+super.toString()
                                +"Salario Base: "+getSalarioBase());
        }
    
}