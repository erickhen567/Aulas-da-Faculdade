package JavaHerancas;

public class Teste {
    public static void main(String[] args){
        EmpregadoComissionadoSalarioBase emp = new EmpregadoComissionadoSalarioBase("Bob", "Santos", "333-33-3333", 5000, .04, 300);
        
        emp.rendimentos();
        
        System.out.println("Resultados: "+emp.toString());
        System.out.println("Nome: "+emp.getPrimeiroNome());
    }
    
}