const mysql = require('mysql2');


const connection = mysql.createConnection({
  host: 'localhost',
  user: 'erick',
  password: '1212',
  database: 'microempreendedores'
});


connection.connect((err) => {
  if (err) {
    console.error('Erro de conexão: ' + err.stack);
    return;
  }
  console.log('Conectado ao banco de dados com ID ' + connection.threadId);
});

module.exports = connection;
