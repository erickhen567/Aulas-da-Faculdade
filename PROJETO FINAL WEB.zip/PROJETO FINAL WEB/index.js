const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const app = express();
const port = 5500;

const connection = require('./db'); 
app.use(express.json());
app.use(express.urlencoded({ extended: true }));


app.use(express.static(path.join(__dirname, 'public')));


app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});


app.get('/consultar', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'consultar.html'));
});


app.get('/registrar', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'registrar.html'));
});


app.post('/login', (req, res) => {
    const { email, senha } = req.body;

    const query = 'SELECT * FROM Empreendedores WHERE email = ? AND senha = ?';
    
    connection.query(query, [email, senha], (err, results) => {
        if (err) {
            return res.status(500).send("Erro no servidor");
        }
        
        if (results.length > 0) {
            
            res.send("Login bem-sucedido!");
        } else {
            
            res.send("Credenciais incorretas!");
        }
    });
});


app.post('/registrar', (req, res) => {
    const { nome, email, senha, telefone, endereco } = req.body;

    const query = 'INSERT INTO Empreendedores (nome, email, senha, telefone, endereco) VALUES (?, ?, ?, ?, ?)';

    connection.query(query, [nome, email, senha, telefone, endereco], (err, results) => {
        if (err) {
            return res.status(500).send("Erro no servidor ao cadastrar o usuário.");
        }
        
        res.send("Cadastro realizado com sucesso!");
    });
});


app.listen(port, () => {
    console.log(`Servidor rodando na porta ${port}`);
});
