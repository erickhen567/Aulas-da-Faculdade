// =========================
// BANCO LOCAL (localStorage)
// =========================

// Carrega vendas
function getVendas() {
    return JSON.parse(localStorage.getItem("vendas")) || [];
}

// Salva vendas
function saveVendas(lista) {
    localStorage.setItem("vendas", JSON.stringify(lista));
}

// Carrega empreendedores
function getEmpreendedores() {
    return JSON.parse(localStorage.getItem("empreendedores")) || [];
}

// =========================
// REGISTRAR VENDA
// =========================

function registrarVenda() {
    const form = document.getElementById("form-venda");
    if (!form) return; // só roda no registrar.html

    form.addEventListener("submit", function (e) {
        e.preventDefault();

        const empresa = document.getElementById("v-empresa").value;
        const prod = document.getElementById("v-prod").value;
        const qty = Number(document.getElementById("v-qty").value);
        const price = Number(document.getElementById("v-price").value);
        const date = document.getElementById("v-date").value;

        const vendas = getVendas();

        vendas.push({
            id: Date.now(),
            empresa,
            prod,
            qty,
            price,
            total: qty * price,
            date
        });

        saveVendas(vendas);
        alert("Venda registrada!");
        form.reset();
    });

    // Exportar CSV
    const btnCSV = document.getElementById("export-csv");
    btnCSV.onclick = exportarCSV;
}

// =========================
// CONSULTAR VENDAS + FILTROS
// =========================

function consultarVendas() {
    const campoBusca = document.getElementById("f-busca");
    if (!campoBusca) return; // só roda no consultar.html

    const fBusca = document.getElementById("f-busca");
    const fStart = document.getElementById("f-start");
    const fEnd = document.getElementById("f-end");
    const fEmp = document.getElementById("f-empreendedor");
    const btnAplicar = document.getElementById("f-aplicar");
    const btnReset = document.getElementById("f-reset");

    btnAplicar.onclick = filtrar;
    btnReset.onclick = function () {
        fBusca.value = "";
        fStart.value = "";
        fEnd.value = "";
        fEmp.value = "";
        filtrar();
    };

    filtrar(); // carrega ao abrir
}

function filtrar() {
    const vendas = getVendas();

    const busca = document.getElementById("f-busca").value.toLowerCase();
    const start = document.getElementById("f-start").value;
    const end = document.getElementById("f-end").value;
    const emp = document.getElementById("f-empreendedor").value;

    let filtrado = vendas.filter(v => {
        const txt = (v.prod + " " + v.empresa).toLowerCase();

        if (busca && !txt.includes(busca)) return false;
        if (emp && v.empresa !== emp) return false;
        if (start && v.date < start) return false;
        if (end && v.date > end) return false;

        return true;
    });

    renderTabela(filtrado);
}

// =========================
// TABELA
// =========================
function renderTabela(lista) {
    const area = document.getElementById("resultado");
    const totalReg = document.getElementById("total-reg");

    if (!area) return;

    totalReg.textContent = lista.length;

    if (lista.length === 0) {
        area.innerHTML = "<p>Nenhum registro encontrado.</p>";
        return;
    }

    let html = `
        <table class="tabela">
            <tr>
                <th>Data</th>
                <th>Empreendedor</th>
                <th>Produto</th>
                <th>Qtd</th>
                <th>Preço</th>
                <th>Total</th>
            </tr>
    `;

    lista.forEach(v => {
        html += `
            <tr>
                <td>${v.date}</td>
                <td>${v.empresa}</td>
                <td>${v.prod}</td>
                <td>${v.qty}</td>
                <td>R$ ${v.price.toFixed(2)}</td>
                <td>R$ ${v.total.toFixed(2)}</td>
            </tr>
        `;
    });

    html += "</table>";

    area.innerHTML = html;
}


// =========================
// EXPORTAR CSV
// =========================

function exportarCSV() {
    const vendas = getVendas();
    if (vendas.length === 0) {
        alert("Nenhuma venda para exportar.");
        return;
    }

    let csv = "Data;Empreendedor;Produto;Qtd;Preço;Total\n";

    vendas.forEach(v => {
        csv += `${v.date};${v.empresa};${v.prod};${v.qty};${v.price};${v.total}\n`;
    });

    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");

    a.href = url;
    a.download = "vendas.csv";
    a.click();
    URL.revokeObjectURL(url);
}


// =========================
// INICIALIZAR
// =========================

registrarVenda();
consultarVendas();
