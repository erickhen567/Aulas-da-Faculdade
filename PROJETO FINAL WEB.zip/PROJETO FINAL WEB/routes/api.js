
const express = require('express');
const router = express.Router();
const db = require('../db');  


const createProduct = (req, res) => {
    const { nome_produto_servico, descricao, preco, estoque } = req.body;
    if (!nome_produto_servico || !descricao || !preco) {
        return res.status(400).json({ message: 'Dados incompletos.' });
    }
    const query = 'INSERT INTO Produtos_Servicos (nome_produto_servico, descricao, preco, estoque) VALUES (?, ?, ?, ?)';
    db.query(query, [nome_produto_servico, descricao, preco, estoque], (err, results) => {
        if (err) {
            return res.status(500).json({ message: 'Erro ao salvar o produto.' });
        }
        res.status(201).json({ message: 'Produto cadastrado!', productId: results.insertId });
    });
};

const getProducts = (req, res) => {
    const query = 'SELECT * FROM Produtos_Servicos';
    db.query(query, (err, results) => {
        if (err) {
            return res.status(500).json({ message: 'Erro ao buscar produtos.' });
        }
        res.status(200).json(results);
    });
};

const updateProduct = (req, res) => {
    const { id } = req.params;
    const { nome_produto_servico, descricao, preco, estoque } = req.body;
    const query = 'UPDATE Produtos_Servicos SET nome_produto_servico = ?, descricao = ?, preco = ?, estoque = ? WHERE id = ?';
    db.query(query, [nome_produto_servico, descricao, preco, estoque, id], (err, results) => {
        if (err) {
            return res.status(500).json({ message: 'Erro ao atualizar produto.' });
        }
        res.status(200).json({ message: 'Produto atualizado com sucesso!' });
    });
};

const deleteProduct = (req, res) => {
    const { id } = req.params;
    const query = 'DELETE FROM Produtos_Servicos WHERE id = ?';
    db.query(query, [id], (err, results) => {
        if (err) {
            return res.status(500).json({ message: 'Erro ao excluir produto.' });
        }
        res.status(200).json({ message: 'Produto excluído com sucesso!' });
    });
};

// Rotas
router.post('/create', createProduct);
router.get('/list', getProducts);
router.put('/update/:id', updateProduct);
router.delete('/delete/:id', deleteProduct);

module.exports = router;
