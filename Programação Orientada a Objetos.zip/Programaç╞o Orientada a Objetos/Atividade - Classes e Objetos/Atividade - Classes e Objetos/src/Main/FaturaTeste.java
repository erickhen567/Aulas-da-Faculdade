package Main;

public class FaturaTeste {
    public static void main(String[] args) {
        
        Fatura fatura1 = new Fatura("01", "Produto", 2, 150.0);
        System.out.println("Fatura 1 - Descrição:" + fatura1.getDescricao());
        System.out.println("Total da fatura: " + fatura1.getTotalFatura());

        
        Fatura fatura2 = new Fatura("02", "Produto", -1, -200.0);
        System.out.println("\nFatura 2 - Descrição:" + fatura2.getDescricao());
        System.out.println("Total da fatura: " + fatura2.getTotalFatura());
    }
}

